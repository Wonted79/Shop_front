<template>
  <footer class="text-body-secondary py-5">
    <div class="container">
      <p class="float-end mb-1"></p>

    </div>
  </footer>
</template>

<script>
export default {
  name: 'Footer'
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
